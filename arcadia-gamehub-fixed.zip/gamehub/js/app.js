// Online/offline status indicator
const statusDot = document.querySelector('.status-dot');
const statusText = document.querySelector('.status-text');

function updateConnectionStatus() {
  if (navigator.onLine) {
    statusDot.classList.remove('offline');
    statusText.textContent = 'Online';
  } else {
    statusDot.classList.add('offline');
    statusText.textContent = 'Offline';
  }
}
window.addEventListener('online', updateConnectionStatus);
window.addEventListener('offline', updateConnectionStatus);
updateConnectionStatus();

// PWA install — handles Chrome/Android (native prompt) and
// iOS/Safari/desktop browsers that don't support beforeinstallprompt
// by showing manual "Add to Home Screen" steps instead.
let deferredPrompt;
const installBtn = document.getElementById('installBtn');
const installModal = document.getElementById('installModal');
const installModalBody = document.getElementById('installModalBody');
const installModalClose = document.getElementById('installModalClose');

function isStandalone() {
  return window.matchMedia('(display-mode: standalone)').matches
    || window.navigator.standalone === true;
}

function detectPlatform() {
  const ua = navigator.userAgent;
  const isIOS = /iphone|ipad|ipod/i.test(ua);
  const isSafari = /^((?!chrome|android).)*safari/i.test(ua);
  const isAndroid = /android/i.test(ua);
  return { isIOS, isSafari, isAndroid };
}

function installInstructionsHTML() {
  const { isIOS, isAndroid } = detectPlatform();

  if (isIOS) {
    return `
      <p>Install Arcadia on your iPhone/iPad:</p>
      <ol>
        <li>Tap the <strong>Share</strong> icon (square with an arrow) in Safari's toolbar</li>
        <li>Scroll down and tap <strong>Add to Home Screen</strong></li>
        <li>Tap <strong>Add</strong> in the top right</li>
      </ol>
      <p class="install-note">Arcadia will appear on your home screen and open full-screen, working fully offline after the first visit.</p>
    `;
  }

  if (isAndroid) {
    return `
      <p>Install Arcadia on Android:</p>
      <ol>
        <li>Tap the <strong>&#8942;</strong> menu (top right of Chrome)</li>
        <li>Tap <strong>Add to Home screen</strong> or <strong>Install app</strong></li>
        <li>Confirm by tapping <strong>Install</strong></li>
      </ol>
      <p class="install-note">Arcadia will work offline once installed.</p>
    `;
  }

  return `
    <p>Install Arcadia on desktop:</p>
    <ol>
      <li>Look for an <strong>install icon</strong> in your browser's address bar (usually a monitor or plus icon)</li>
      <li>Click it, then confirm <strong>Install</strong></li>
    </ol>
    <p class="install-note">If you don't see it, your browser may not support installing this app — Chrome and Edge work best.</p>
  `;
}

function openInstallModal() {
  installModalBody.innerHTML = installInstructionsHTML();
  installModal.hidden = false;
}

function closeInstallModal() {
  installModal.hidden = true;
}

function showInstallButton() {
  if (isStandalone()) return; // already installed, nothing to do
  installBtn.hidden = false;
}

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  showInstallButton();
});

installBtn?.addEventListener('click', async () => {
  if (deferredPrompt) {
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      installBtn.hidden = true;
    }
    deferredPrompt = null;
  } else {
    // No native prompt available (iOS, desktop Safari, Firefox, etc.)
    openInstallModal();
  }
});

installModalClose?.addEventListener('click', closeInstallModal);
installModal?.addEventListener('click', (e) => {
  if (e.target === installModal) closeInstallModal();
});

window.addEventListener('appinstalled', () => {
  installBtn.hidden = true;
});

// Always show the install button unless already running as an installed app,
// so people on iOS/Safari/Firefox still have a clear path to offline install.
if (!isStandalone()) {
  showInstallButton();
}

// Register service worker for offline support
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').catch((err) => {
      console.warn('Service worker registration failed:', err);
    });
  });
}
