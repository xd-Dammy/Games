const boardEl = document.getElementById('lightsBoard');
const movesValEl = document.getElementById('movesVal');
const bestValEl = document.getElementById('bestVal');
const statusMsg = document.getElementById('statusMsg');
const resetBtn = document.getElementById('resetBtn');
const hintBtn = document.getElementById('hintBtn');
const sizeBtns = document.querySelectorAll('.mode-btn');

let gridSize = 4;
let grid = [];
let moves = 0;
let solved = false;

function bestKey() {
  return `lightsout-best-${gridSize}`;
}

function loadBest() {
  const saved = localStorage.getItem(bestKey());
  bestValEl.textContent = saved ? saved : '—';
}

function maybeSaveBest() {
  const saved = localStorage.getItem(bestKey());
  if (!saved || moves < parseInt(saved, 10)) {
    localStorage.setItem(bestKey(), String(moves));
    loadBest();
  }
}

function idx(r, c) { return r * gridSize + c; }

function toggle(r, c) {
  if (r < 0 || r >= gridSize || c < 0 || c >= gridSize) return;
  grid[idx(r, c)] = grid[idx(r, c)] ? 0 : 1;
}

function press(r, c) {
  toggle(r, c);
  toggle(r - 1, c);
  toggle(r + 1, c);
  toggle(r, c - 1);
  toggle(r, c + 1);
}

// Generate a solvable puzzle by starting from all-off and
// applying a series of random presses (presses are self-inverse,
// so any resulting state is guaranteed solvable).
function generatePuzzle(size) {
  grid = Array(size * size).fill(0);
  const pressCount = size * size; // enough scrambling
  const pressed = new Set();
  for (let i = 0; i < pressCount; i++) {
    const r = Math.floor(Math.random() * size);
    const c = Math.floor(Math.random() * size);
    press(r, c);
    const key = `${r},${c}`;
    if (pressed.has(key)) pressed.delete(key); else pressed.add(key);
  }
  // Avoid an already-solved scramble
  if (grid.every(v => v === 0)) {
    const r = Math.floor(Math.random() * size);
    const c = Math.floor(Math.random() * size);
    press(r, c);
  }
}

function renderBoard() {
  boardEl.style.gridTemplateColumns = `repeat(${gridSize}, 1fr)`;
  boardEl.innerHTML = '';
  for (let r = 0; r < gridSize; r++) {
    for (let c = 0; c < gridSize; c++) {
      const cell = document.createElement('button');
      cell.className = 'light-cell';
      if (grid[idx(r, c)]) cell.classList.add('on');
      cell.setAttribute('aria-label', `Light ${r + 1},${c + 1}`);
      cell.addEventListener('click', () => handlePress(r, c));
      boardEl.appendChild(cell);
    }
  }
}

function handlePress(r, c) {
  if (solved) return;
  press(r, c);
  moves++;
  movesValEl.textContent = moves;
  renderBoard();

  if (grid.every(v => v === 0)) {
    solved = true;
    statusMsg.textContent = `Solved in ${moves} moves!`;
    maybeSaveBest();
  } else {
    statusMsg.textContent = 'Turn off every light to win';
  }
}

// Simple hint: highlight a lit cell to nudge the player toward it.
// Full optimal-solution solving is heavier than needed for a mobile hint;
// pressing a currently-lit cell is always a reasonable next move.
function showHint() {
  if (solved) return;
  const litCells = [];
  for (let r = 0; r < gridSize; r++) {
    for (let c = 0; c < gridSize; c++) {
      if (grid[idx(r, c)]) litCells.push([r, c]);
    }
  }
  if (litCells.length === 0) return;
  const [hr, hc] = litCells[Math.floor(Math.random() * litCells.length)];
  const cells = boardEl.querySelectorAll('.light-cell');
  cells.forEach(cell => cell.classList.remove('hint'));
  cells[idx(hr, hc)].classList.add('hint');
  statusMsg.textContent = 'Try the highlighted light';
  setTimeout(() => {
    cells[idx(hr, hc)]?.classList.remove('hint');
  }, 1200);
}

function newGame() {
  moves = 0;
  solved = false;
  movesValEl.textContent = '0';
  statusMsg.textContent = 'Turn off every light to win';
  generatePuzzle(gridSize);
  loadBest();
  renderBoard();
}

resetBtn.addEventListener('click', newGame);
hintBtn.addEventListener('click', showHint);

sizeBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    gridSize = parseInt(btn.dataset.size, 10);
    sizeBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    newGame();
  });
});

newGame();
