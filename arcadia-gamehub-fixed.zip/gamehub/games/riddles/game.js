const riddleText = document.getElementById('riddleText');
const optionsEl = document.getElementById('riddleOptions');
const statusEl = document.getElementById('riddleStatus');
const hintBtn = document.getElementById('hintBtn');
const skipBtn = document.getElementById('skipBtn');
const streakValEl = document.getElementById('streakVal');
const solvedValEl = document.getElementById('solvedVal');
const bestStreakValEl = document.getElementById('bestStreakVal');
const catBtns = document.querySelectorAll('.mode-btn');

let category = 'riddle';
let pool = [];
let currentIndex = -1;
let streak = 0;
let solved = 0;
let bestStreak = 0;
let answered = false;

function loadStats() {
  streak = parseInt(localStorage.getItem('riddle-streak') || '0', 10);
  solved = parseInt(localStorage.getItem('riddle-solved') || '0', 10);
  bestStreak = parseInt(localStorage.getItem('riddle-best-streak') || '0', 10);
  updateStatsDisplay();
}

function saveStats() {
  localStorage.setItem('riddle-streak', String(streak));
  localStorage.setItem('riddle-solved', String(solved));
  localStorage.setItem('riddle-best-streak', String(bestStreak));
}

function updateStatsDisplay() {
  streakValEl.textContent = streak;
  solvedValEl.textContent = solved;
  bestStreakValEl.textContent = bestStreak;
}

function buildPool() {
  pool = RIDDLE_BANK
    .map((item, idx) => ({ ...item, idx }))
    .filter(item => item.cat === category);
}

function pickNextRiddle() {
  answered = false;
  if (pool.length === 0) buildPool();
  let next;
  do {
    next = Math.floor(Math.random() * pool.length);
  } while (pool.length > 1 && next === currentIndex);
  currentIndex = next;

  const item = pool[currentIndex];
  riddleText.textContent = item.q;
  statusEl.textContent = 'Pick the answer you think is right';

  const optionOrder = item.options.map((text, i) => ({ text, isCorrect: i === item.answer }));
  optionsEl.innerHTML = '';
  optionOrder.forEach(opt => {
    const btn = document.createElement('button');
    btn.className = 'option-btn';
    btn.textContent = opt.text;
    btn.addEventListener('click', () => handleAnswer(btn, opt.isCorrect));
    optionsEl.appendChild(btn);
  });
}

function handleAnswer(btn, isCorrect) {
  if (answered) return;
  answered = true;

  const buttons = optionsEl.querySelectorAll('.option-btn');
  buttons.forEach(b => b.disabled = true);

  if (isCorrect) {
    btn.classList.add('correct');
    streak++;
    solved++;
    if (streak > bestStreak) bestStreak = streak;
    statusEl.textContent = 'Correct! Next one coming up...';
    saveStats();
    updateStatsDisplay();
    setTimeout(pickNextRiddle, 1200);
  } else {
    btn.classList.add('wrong');
    const item = pool[currentIndex];
    const correctBtn = Array.from(buttons)[item.answer];
    correctBtn.classList.add('correct');
    streak = 0;
    statusEl.textContent = 'Not quite — streak reset';
    saveStats();
    updateStatsDisplay();
  }
}

function showHint() {
  if (answered) return;
  const item = pool[currentIndex];
  statusEl.textContent = `Hint: ${item.hint}`;
}

function skipRiddle() {
  streak = 0;
  saveStats();
  updateStatsDisplay();
  pickNextRiddle();
}

catBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    category = btn.dataset.cat;
    catBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    buildPool();
    pickNextRiddle();
  });
});

hintBtn.addEventListener('click', showHint);
skipBtn.addEventListener('click', skipRiddle);

loadStats();
buildPool();
pickNextRiddle();
