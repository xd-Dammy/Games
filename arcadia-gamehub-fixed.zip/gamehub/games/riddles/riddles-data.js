// Each entry: question text, list of options, index of correct answer,
// optional hint, and category ('riddle' or 'trick').
const RIDDLE_BANK = [
  {
    cat: 'riddle',
    q: "I speak without a mouth and hear without ears. I have no body, but I come alive with wind. What am I?",
    options: ["An echo", "A ghost", "A whisper", "A radio"],
    answer: 0,
    hint: "Shout in a canyon and you'll hear it answer back."
  },
  {
    cat: 'riddle',
    q: "The more you take, the more you leave behind. What am I?",
    options: ["Money", "Footsteps", "Time", "Memories"],
    answer: 1,
    hint: "Think about walking on sand."
  },
  {
    cat: 'riddle',
    q: "What has keys but can't open locks?",
    options: ["A map", "A piano", "A dictionary", "A safe"],
    answer: 1,
    hint: "You play it, not unlock it."
  },
  {
    cat: 'riddle',
    q: "What has a neck but no head?",
    options: ["A shirt", "A bottle", "A guitar", "A road"],
    answer: 1,
    hint: "You'd find this on a table, holding a drink."
  },
  {
    cat: 'riddle',
    q: "What gets wetter the more it dries?",
    options: ["A sponge", "Rain", "A towel", "The ocean"],
    answer: 2,
    hint: "You use it right after a shower."
  },
  {
    cat: 'riddle',
    q: "What can travel around the world while staying in a corner?",
    options: ["A satellite", "A stamp", "A spider", "The wind"],
    answer: 1,
    hint: "It sticks to the corner of an envelope."
  },
  {
    cat: 'riddle',
    q: "What has many teeth but cannot bite?",
    options: ["A shark", "A comb", "A gear", "A saw"],
    answer: 1,
    hint: "You run it through your hair."
  },
  {
    cat: 'riddle',
    q: "I'm tall when I'm young and short when I'm old. What am I?",
    options: ["A tree", "A candle", "A person", "A shadow"],
    answer: 1,
    hint: "It melts as it burns."
  },
  {
    cat: 'riddle',
    q: "What goes up but never comes down?",
    options: ["A balloon", "Your age", "Smoke", "A rocket"],
    answer: 1,
    hint: "It happens once a year, on your birthday."
  },
  {
    cat: 'riddle',
    q: "What has one eye but can't see?",
    options: ["A needle", "A storm", "A potato", "A cyclops"],
    answer: 0,
    hint: "Thread goes through it."
  },
  {
    cat: 'riddle',
    q: "What comes once in a minute, twice in a moment, but never in a thousand years?",
    options: ["The letter M", "A heartbeat", "A second", "A blink"],
    answer: 0,
    hint: "Look at the spelling of the words in this riddle."
  },
  {
    cat: 'riddle',
    q: "What can you catch but not throw?",
    options: ["A ball", "A cold", "A fish", "A thief"],
    answer: 1,
    hint: "You definitely don't want to catch this one."
  },
  {
    cat: 'trick',
    q: "A farmer has 17 sheep. All but 9 die. How many sheep are left?",
    options: ["8", "9", "17", "0"],
    answer: 1,
    hint: "Read the phrase 'all but 9' very literally."
  },
  {
    cat: 'trick',
    q: "How many months have 28 days?",
    options: ["1", "6", "12", "11"],
    answer: 2,
    hint: "Every month has at least 28 days."
  },
  {
    cat: 'trick',
    q: "If a plane crashes exactly on the border of the US and Canada, where do they bury the survivors?",
    options: ["USA", "Canada", "Halfway between", "You don't bury survivors"],
    answer: 3,
    hint: "Survivors, by definition, are still alive."
  },
  {
    cat: 'trick',
    q: "What weighs more: a pound of feathers or a pound of bricks?",
    options: ["Feathers", "Bricks", "They weigh the same", "Depends on the scale"],
    answer: 2,
    hint: "A pound is a pound, regardless of material."
  },
  {
    cat: 'trick',
    q: "Two mothers and two daughters go fishing. They only catch 3 fish, but everyone still gets one. How?",
    options: ["One fish was split", "They bought more fish", "It's a grandmother, mother, and daughter", "One person didn't eat"],
    answer: 2,
    hint: "Three generations means only three people total."
  },
  {
    cat: 'trick',
    q: "A rooster lays an egg on top of a barn roof. Which way does it roll?",
    options: ["Left", "Right", "It doesn't roll", "Straight down the middle"],
    answer: 2,
    hint: "Roosters are male — think about that."
  },
  {
    cat: 'trick',
    q: "You're in a race and you pass the person in 2nd place. What place are you in now?",
    options: ["1st", "2nd", "3rd", "Last"],
    answer: 1,
    hint: "You took their spot, not the leader's."
  },
  {
    cat: 'trick',
    q: "How many times can you subtract 5 from 25?",
    options: ["5", "1", "0", "25"],
    answer: 1,
    hint: "After the first subtraction, it's no longer 25."
  },
  {
    cat: 'trick',
    q: "A man builds a rectangular house with four walls, each facing south. A bear walks by. What color is the bear?",
    options: ["Brown", "Black", "White", "There is no bear"],
    answer: 2,
    hint: "Only one place on Earth has every direction facing south."
  }
];
