// ===== Mode switching =====
const modeBtns = document.querySelectorAll('.mode-btn');
const nimSection = document.getElementById('nimSection');
const tfSection = document.getElementById('twentyfourSection');

modeBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    modeBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const game = btn.dataset.game;
    nimSection.hidden = game !== 'nim';
    tfSection.hidden = game !== 'twentyfour';
  });
});

// ===== NIM =====
const sticksRow = document.getElementById('sticksRow');
const nimCountEl = document.getElementById('nimCount');
const nimWinsEl = document.getElementById('nimWins');
const nimStatus = document.getElementById('nimStatus');
const nimResetBtn = document.getElementById('nimReset');
const takeBtns = document.querySelectorAll('.pill-btn[data-take]');

const NIM_START = 15;
let nimSticks = NIM_START;
let nimTurn = 'player'; // player | cpu
let nimOver = false;
let nimWins = 0;

function loadNimWins() {
  nimWins = parseInt(localStorage.getItem('nim-wins') || '0', 10);
  nimWinsEl.textContent = nimWins;
}

function renderSticks() {
  sticksRow.innerHTML = '';
  for (let i = 0; i < NIM_START; i++) {
    const s = document.createElement('div');
    s.className = 'stick';
    if (i >= nimSticks) s.classList.add('removed');
    sticksRow.appendChild(s);
  }
  nimCountEl.textContent = nimSticks;
}

function updateTakeButtons() {
  takeBtns.forEach(btn => {
    const take = parseInt(btn.dataset.take, 10);
    btn.disabled = nimOver || take > nimSticks || nimTurn !== 'player';
  });
}

function nimPlayerTake(n) {
  if (nimOver || nimTurn !== 'player') return;
  n = Math.min(n, nimSticks);
  nimSticks -= n;
  renderSticks();

  if (nimSticks === 0) {
    endNim(false); // player took last stick -> player loses
    return;
  }

  nimTurn = 'cpu';
  nimStatus.textContent = "CPU's turn...";
  updateTakeButtons();
  setTimeout(cpuTakeNim, 500);
}

function cpuTakeNim() {
  if (nimOver) return;
  // Optimal strategy: leave a multiple of 4 sticks for the opponent.
  let take = nimSticks % 4;
  if (take === 0) take = 1 + Math.floor(Math.random() * Math.min(3, nimSticks));
  take = Math.max(1, Math.min(take, nimSticks, 3));

  nimSticks -= take;
  renderSticks();

  if (nimSticks === 0) {
    endNim(true); // CPU took last stick -> CPU loses, player wins
    return;
  }

  nimTurn = 'player';
  nimStatus.textContent = `CPU took ${take}. Your turn — take 1, 2, or 3`;
  updateTakeButtons();
}

function endNim(playerWon) {
  nimOver = true;
  if (playerWon) {
    nimWins++;
    localStorage.setItem('nim-wins', String(nimWins));
    nimWinsEl.textContent = nimWins;
    nimStatus.textContent = 'CPU took the last stick — you win!';
  } else {
    nimStatus.textContent = 'You took the last stick — CPU wins!';
  }
  updateTakeButtons();
}

function newNimGame() {
  nimSticks = NIM_START;
  nimTurn = 'player';
  nimOver = false;
  nimStatus.textContent = 'Your turn — take 1, 2, or 3';
  loadNimWins();
  renderSticks();
  updateTakeButtons();
}

takeBtns.forEach(btn => {
  btn.addEventListener('click', () => nimPlayerTake(parseInt(btn.dataset.take, 10)));
});
nimResetBtn.addEventListener('click', newNimGame);

newNimGame();

// ===== 24 GAME =====
const tfCardsEl = document.getElementById('tfCards');
const tfExprEl = document.getElementById('tfExpr');
const tfOpsEl = document.getElementById('tfOps');
const tfStatus = document.getElementById('tfStatus');
const tfClearBtn = document.getElementById('tfClear');
const tfSubmitBtn = document.getElementById('tfSubmit');
const tfResetBtn = document.getElementById('tfReset');
const tfSolvedEl = document.getElementById('tfSolved');

let tfNumbers = [];
let tfUsed = [];
let tfTokens = []; // array of {type: 'num'|'op', value, cardIndex?}
let tfSolvedCount = 0;

function loadTfSolved() {
  tfSolvedCount = parseInt(localStorage.getItem('tf-solved') || '0', 10);
  tfSolvedEl.textContent = tfSolvedCount;
}

// Generate 4 numbers (1-9) that are guaranteed solvable to 24
function generateSolvable24() {
  for (let attempt = 0; attempt < 500; attempt++) {
    const nums = Array.from({ length: 4 }, () => 1 + Math.floor(Math.random() * 9));
    if (isSolvable24(nums)) return nums;
  }
  return [3, 3, 8, 8]; // known solvable fallback (8/(3-8/3))
}

function isSolvable24(nums) {
  const EPS = 1e-6;
  function helper(arr) {
    if (arr.length === 1) return Math.abs(arr[0] - 24) < EPS;
    for (let i = 0; i < arr.length; i++) {
      for (let j = 0; j < arr.length; j++) {
        if (i === j) continue;
        const rest = arr.filter((_, idx) => idx !== i && idx !== j);
        const a = arr[i], b = arr[j];
        const results = [a + b, a - b, a * b];
        if (Math.abs(b) > EPS) results.push(a / b);
        for (const r of results) {
          if (helper([...rest, r])) return true;
        }
      }
    }
    return false;
  }
  return helper(nums);
}

function renderTfCards() {
  tfCardsEl.innerHTML = '';
  tfNumbers.forEach((num, i) => {
    const card = document.createElement('div');
    card.className = 'tf-card';
    if (tfUsed[i]) card.classList.add('used');
    card.textContent = num;
    card.addEventListener('click', () => addNumberToken(i));
    tfCardsEl.appendChild(card);
  });
}

function addNumberToken(cardIndex) {
  if (tfUsed[cardIndex]) return;
  tfUsed[cardIndex] = true;
  tfTokens.push({ type: 'num', value: tfNumbers[cardIndex], cardIndex });
  renderTfCards();
  renderExpr();
}

function addOpToken(op) {
  tfTokens.push({ type: 'op', value: op });
  renderExpr();
}

function renderExpr() {
  const symbols = { '+': '+', '-': '−', '*': '×', '/': '÷', '(': '(', ')': ')' };
  if (tfTokens.length === 0) {
    tfExprEl.textContent = 'Tap numbers and operators';
    return;
  }
  tfExprEl.textContent = tfTokens.map(t => t.type === 'num' ? t.value : symbols[t.value]).join(' ');
}

function clearExpr() {
  tfTokens = [];
  tfUsed = tfNumbers.map(() => false);
  renderTfCards();
  renderExpr();
  tfStatus.textContent = 'Build an expression that equals 24';
}

function checkExpr() {
  const usedCount = tfTokens.filter(t => t.type === 'num').length;
  if (usedCount < 4) {
    tfStatus.textContent = 'Use all 4 numbers first';
    return;
  }

  const exprStr = tfTokens.map(t => t.value).join(' ');
  // Safe evaluation: only digits, spaces, and + - * / ( ) . are allowed
  if (!/^[0-9+\-*/().\s]+$/.test(exprStr)) {
    tfStatus.textContent = 'Invalid expression';
    return;
  }

  let result;
  try {
    result = evaluateExpr(exprStr);
  } catch (e) {
    tfStatus.textContent = 'Invalid expression';
    return;
  }

  if (result === null) {
    tfStatus.textContent = 'Invalid expression';
    return;
  }

  if (Math.abs(result - 24) < 1e-6) {
    tfStatus.textContent = 'Nailed it — that equals 24!';
    tfSolvedCount++;
    localStorage.setItem('tf-solved', String(tfSolvedCount));
    tfSolvedEl.textContent = tfSolvedCount;
    setTimeout(newTfRound, 1200);
  } else {
    tfStatus.textContent = `That equals ${formatNum(result)} — try again`;
  }
}

function formatNum(n) {
  return Math.round(n * 1000) / 1000;
}

// Small recursive-descent evaluator — avoids using eval()
function evaluateExpr(str) {
  let pos = 0;
  const s = str.replace(/\s+/g, '');

  function peek() { return s[pos]; }
  function consume() { return s[pos++]; }

  function parseExpression() {
    let value = parseTerm();
    while (peek() === '+' || peek() === '-') {
      const op = consume();
      const rhs = parseTerm();
      value = op === '+' ? value + rhs : value - rhs;
    }
    return value;
  }

  function parseTerm() {
    let value = parseFactor();
    while (peek() === '*' || peek() === '/') {
      const op = consume();
      const rhs = parseFactor();
      if (op === '/') {
        if (Math.abs(rhs) < 1e-9) throw new Error('div by zero');
        value = value / rhs;
      } else {
        value = value * rhs;
      }
    }
    return value;
  }

  function parseFactor() {
    if (peek() === '(') {
      consume();
      const value = parseExpression();
      if (peek() !== ')') throw new Error('mismatched parens');
      consume();
      return value;
    }
    if (peek() === '-') {
      consume();
      return -parseFactor();
    }
    let numStr = '';
    while (peek() && /[0-9.]/.test(peek())) {
      numStr += consume();
    }
    if (!numStr) throw new Error('expected number');
    return parseFloat(numStr);
  }

  const result = parseExpression();
  if (pos !== s.length) throw new Error('unexpected trailing input');
  return result;
}

function newTfRound() {
  tfNumbers = generateSolvable24();
  tfUsed = tfNumbers.map(() => false);
  tfTokens = [];
  renderTfCards();
  renderExpr();
  tfStatus.textContent = 'Build an expression that equals 24';
}

tfOpsEl.querySelectorAll('.op-btn').forEach(btn => {
  btn.addEventListener('click', () => addOpToken(btn.dataset.op));
});
tfClearBtn.addEventListener('click', clearExpr);
tfSubmitBtn.addEventListener('click', checkExpr);
tfResetBtn.addEventListener('click', newTfRound);

loadTfSolved();
newTfRound();
