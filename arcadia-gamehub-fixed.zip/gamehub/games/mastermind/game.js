const historyEl = document.getElementById('mmHistory');
const currentEl = document.getElementById('mmCurrent');
const paletteEl = document.getElementById('mmPalette');
const submitBtn = document.getElementById('submitBtn');
const resetBtn = document.getElementById('resetBtn');
const guessesValEl = document.getElementById('guessesVal');
const winsValEl = document.getElementById('winsVal');
const statusMsg = document.getElementById('statusMsg');
const diffBtns = document.querySelectorAll('.mode-btn');

const ALL_COLORS = ['#FF3D6E', '#3DDCFF', '#FFD23D', '#4ADE80', '#A78BFA', '#FB923C', '#F472B6', '#38BDF8'];

const DIFFICULTIES = {
  easy:   { colors: 4, slots: 4, guesses: 12 },
  medium: { colors: 6, slots: 4, guesses: 10 },
  hard:   { colors: 6, slots: 5, guesses: 10 }
};

let difficulty = 'easy';
let config = DIFFICULTIES.easy;
let secretCode = [];
let currentGuess = [];
let guessesLeft = 0;
let gameOver = false;
let wins = 0;

function loadWins() {
  wins = parseInt(localStorage.getItem('mastermind-wins') || '0', 10);
  winsValEl.textContent = wins;
}

function saveWins() {
  localStorage.setItem('mastermind-wins', String(wins));
}

function generateCode() {
  const code = [];
  for (let i = 0; i < config.slots; i++) {
    code.push(Math.floor(Math.random() * config.colors));
  }
  return code;
}

function renderPalette() {
  paletteEl.innerHTML = '';
  for (let i = 0; i < config.colors; i++) {
    const btn = document.createElement('button');
    btn.className = 'color-btn';
    btn.style.background = ALL_COLORS[i];
    btn.addEventListener('click', () => addPeg(i));
    paletteEl.appendChild(btn);
  }
}

function renderCurrent() {
  currentEl.innerHTML = '';
  for (let i = 0; i < config.slots; i++) {
    const slot = document.createElement('div');
    slot.className = 'slot';
    if (currentGuess[i] !== undefined) {
      slot.classList.add('filled');
      slot.style.background = ALL_COLORS[currentGuess[i]];
    }
    slot.addEventListener('click', () => removePeg(i));
    currentEl.appendChild(slot);
  }
}

function addPeg(colorIndex) {
  if (gameOver) return;
  if (currentGuess.length >= config.slots) return;
  currentGuess.push(colorIndex);
  renderCurrent();
}

function removePeg(i) {
  if (gameOver) return;
  if (i < currentGuess.length) {
    currentGuess.splice(i, 1);
    renderCurrent();
  }
}

function scoreGuess(guess, secret) {
  let exact = 0;
  const secretRemain = [];
  const guessRemain = [];

  for (let i = 0; i < secret.length; i++) {
    if (guess[i] === secret[i]) {
      exact++;
    } else {
      secretRemain.push(secret[i]);
      guessRemain.push(guess[i]);
    }
  }

  let partial = 0;
  const used = Array(secretRemain.length).fill(false);
  for (const g of guessRemain) {
    const idx = secretRemain.findIndex((s, i) => s === g && !used[i]);
    if (idx !== -1) {
      used[idx] = true;
      partial++;
    }
  }

  return { exact, partial };
}

function submitGuess() {
  if (gameOver) return;
  if (currentGuess.length < config.slots) {
    statusMsg.textContent = `Fill all ${config.slots} slots first`;
    return;
  }

  const { exact, partial } = scoreGuess(currentGuess, secretCode);
  addHistoryRow(currentGuess, exact, partial);
  guessesLeft--;
  guessesValEl.textContent = guessesLeft;

  if (exact === config.slots) {
    gameOver = true;
    wins++;
    saveWins();
    statusMsg.textContent = `Solved! The code was cracked.`;
  } else if (guessesLeft <= 0) {
    gameOver = true;
    statusMsg.textContent = `Out of guesses — the code is revealed below`;
    revealCode();
  } else {
    statusMsg.textContent = `${exact} exact, ${partial} close — try again`;
  }

  currentGuess = [];
  renderCurrent();
}

function addHistoryRow(guess, exact, partial) {
  const row = document.createElement('div');
  row.className = 'mm-row';

  const pegs = document.createElement('div');
  pegs.className = 'mm-pegs';
  guess.forEach(colorIdx => {
    const peg = document.createElement('div');
    peg.className = 'peg';
    peg.style.background = ALL_COLORS[colorIdx];
    pegs.appendChild(peg);
  });

  const feedback = document.createElement('div');
  feedback.className = 'mm-feedback';
  const dots = [];
  for (let i = 0; i < exact; i++) dots.push('exact');
  for (let i = 0; i < partial; i++) dots.push('partial');
  while (dots.length < config.slots) dots.push('');
  dots.forEach(type => {
    const dot = document.createElement('div');
    dot.className = `feedback-dot ${type}`;
    feedback.appendChild(dot);
  });

  row.appendChild(pegs);
  row.appendChild(feedback);
  historyEl.appendChild(row);
}

function revealCode() {
  const row = document.createElement('div');
  row.className = 'mm-row';
  const pegs = document.createElement('div');
  pegs.className = 'mm-pegs';
  secretCode.forEach(colorIdx => {
    const peg = document.createElement('div');
    peg.className = 'peg';
    peg.style.background = ALL_COLORS[colorIdx];
    peg.style.boxShadow = `0 0 6px ${ALL_COLORS[colorIdx]}`;
    pegs.appendChild(peg);
  });
  row.appendChild(pegs);
  historyEl.appendChild(row);
}

function newGame() {
  config = DIFFICULTIES[difficulty];
  secretCode = generateCode();
  currentGuess = [];
  guessesLeft = config.guesses;
  gameOver = false;
  guessesValEl.textContent = guessesLeft;
  statusMsg.textContent = 'Crack the code — pick colors, then submit';
  historyEl.innerHTML = '';
  loadWins();
  renderPalette();
  renderCurrent();
}

submitBtn.addEventListener('click', submitGuess);
resetBtn.addEventListener('click', newGame);

diffBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    difficulty = btn.dataset.diff;
    diffBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    newGame();
  });
});

newGame();
