const CACHE_NAME = 'arcadia-v1';
const CORE_ASSETS = [
  './',
  './index.html',
  './css/style.css',
  './js/app.js',
  './manifest.json',
  './games/tictactoe/index.html',
  './games/tictactoe/style.css',
  './games/tictactoe/game.js',
  './games/snake/index.html',
  './games/snake/style.css',
  './games/snake/game.js',
  './games/sudoku/index.html',
  './games/sudoku/style.css',
  './games/sudoku/game.js',
  './games/2048/index.html',
  './games/2048/style.css',
  './games/2048/game.js',
  './games/memory/index.html',
  './games/memory/style.css',
  './games/memory/game.js',
  './games/runner3d/index.html',
  './games/runner3d/style.css',
  './games/runner3d/game.js',
  './games/runner3d/physics.js'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) =>
      // Cache each asset individually so one missing/failed file
      // doesn't abort caching for every other game.
      Promise.all(
        CORE_ASSETS.map((asset) =>
          cache.add(asset).catch((err) => {
            console.warn('Failed to cache', asset, err);
          })
        )
      )
    )
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))
      )
    )
  );
  self.clients.claim();
});

// Cache-first strategy, falling back to network, then caching new responses
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;

  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;

      return fetch(event.request)
        .then((response) => {
          if (!response || response.status !== 200 || response.type !== 'basic') {
            return response;
          }
          const responseClone = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, responseClone));
          return response;
        })
        .catch(() => caches.match('./index.html'));
    })
  );
});
